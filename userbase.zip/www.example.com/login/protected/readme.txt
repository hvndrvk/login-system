See the following page for instructions regarding this folder:

http://encodable.com/userbase/#password-protect-directory

