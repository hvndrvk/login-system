<?PHP $groups_allowed = "member,other_group"; require($_SERVER['DOCUMENT_ROOT'] . "/login/ublock.php"); ?>

Access granted!

