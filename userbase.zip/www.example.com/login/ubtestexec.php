<?PHP

require("call_ub.php");

?>
