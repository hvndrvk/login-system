<?PHP

virtual("/cgi-bin/userbase.cgi?" . $_SERVER['QUERY_STRING']);

?>
